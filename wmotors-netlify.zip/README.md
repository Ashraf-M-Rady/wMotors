# W Motors — website draft (static)

Everything is self-contained: no CDN, no Google Fonts, no external requests.

## Deploy
Upload the whole folder (keep the structure) to any static host:
- Netlify / Vercel / Cloudflare Pages: drag-and-drop this folder.
- cPanel / Plesk / any Apache or Nginx server: copy into the web root (e.g. `public_html`).
- GitHub Pages: push the folder and enable Pages.

`index.html` must stay next to `assets/`, `vendor/`, `fonts/` and `favicon.svg`.

## Local preview
Just double-click `index.html` — it also runs straight from the file system.

## Structure
- `index.html` — the page (intro, 3D shield, scroll reveal, all sections)
- `assets/` — images and the 16 s history reel (`history-reel.mp4`)
- `vendor/` — three.js r128, GSAP 3.12.5 + ScrollTrigger, Lenis 1.1.18 (pinned, local)
- `fonts/` — Plus Jakarta Sans + Instrument Serif (woff2, self-hosted)

## Notes
- Audio is muted by default (browser rule); the "Sound off / on" button in the hero toggles it.
- Replace any image by overwriting the file in `assets/` with the same name, or edit the `src` in `index.html`.
- Tested in Chrome, Safari and Firefox, desktop and mobile. Needs WebGL (every phone/desktop since ~2014).
